// This package is great //@ diag(`package comment should be of the form`)
package pkg
