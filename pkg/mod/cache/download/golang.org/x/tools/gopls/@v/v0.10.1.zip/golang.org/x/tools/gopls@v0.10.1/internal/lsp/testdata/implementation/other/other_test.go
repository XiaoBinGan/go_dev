package other

import (
	"testing"
)

// This exists so the other.test package comes into existence.

func TestOther(t *testing.T) {
}
