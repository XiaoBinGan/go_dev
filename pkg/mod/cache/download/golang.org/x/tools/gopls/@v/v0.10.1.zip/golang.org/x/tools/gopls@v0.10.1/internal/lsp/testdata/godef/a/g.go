package a

import "time"

// dur is a constant of type time.Duration.
const dur = 15*time.Minute + 10*time.Second + 350*time.Millisecond //@dur,hoverdef("dur", dur)
