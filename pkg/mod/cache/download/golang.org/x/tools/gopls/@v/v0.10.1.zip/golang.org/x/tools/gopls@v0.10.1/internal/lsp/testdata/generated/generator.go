package generated

func _() {
	var x int //@diag("x", "compiler", "x declared (and|but) not used", "error")
}
