package data

type B struct {
	ExportedInt   int
	unexportedInt int
}
