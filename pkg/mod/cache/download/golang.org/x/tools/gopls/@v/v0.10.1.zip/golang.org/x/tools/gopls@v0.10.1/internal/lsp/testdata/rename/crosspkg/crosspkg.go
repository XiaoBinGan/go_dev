package crosspkg

func Foo() { //@rename("Foo", "Dolphin")

}

var Bar int //@rename("Bar", "Tomato")
