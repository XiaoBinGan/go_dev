package b

type B struct {
}

func Parse(string, string) B {
	return B{}
}

func (b B) Format(string) {
}
